package com.weather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherApiApplicationTests {
	
	

	@Test
	void contextLoads() {
	}

}
